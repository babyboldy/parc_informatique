# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ParcIntervention(models.Model):
    _inherit = 'helpdesk.ticket'

    # Client lié à l'incident
    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_parc_client', '=', True)], required=True)

    # Équipement concerné
    equipement_id = fields.Many2one('stock.lot', string="Équipement Concerné", required=True)

    # Employé utilisateur (facultatif)
    employee_id = fields.Many2one('hr.employee', string="Employé Utilisateur", required=False)

    # Technicien affecté (utilisateur Odoo)
    technicien_id = fields.Many2one('res.users', string="Technicien Assigné", required=False)

    # Date prévue d'intervention
    date_intervention = fields.Datetime(string="Date d'Intervention Prévue")

    # Statut de clôture (automatiquement géré par `stage_id`, mais on peut en ajouter si besoin)

    @api.constrains('equipement_id')
    def _check_equipement_intervention_possible(self):
        for rec in self:
            if rec.equipement_id.etat_equipement in ['perdu', 'vendu', 'hors_service']:
                raise ValidationError("Impossible de planifier une intervention sur un équipement non disponible.")

    @api.constrains('equipement_id', 'date_debut')
    def _check_intervention_apres_affectation(self):
        for rec in self:
            if rec.equipement_id.date_affectation and rec.date_debut:
                if rec.date_debut < rec.equipement_id.date_affectation:
                    raise ValidationError("L'intervention ne peut pas précéder la date d'affectation de l'équipement.")


