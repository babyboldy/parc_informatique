# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ParcAffectation(models.Model):
    _name = 'parc.affectation'
    _description = "Affectation d'Équipement"
    _order = 'date_affectation desc'

    # Client auquel appartient l'équipement
    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_parc_client', '=', True)], required=True)

    # Équipement affecté
    equipement_id = fields.Many2one('stock.lot', string="Équipement", required=True)

    # Employé à qui l'équipement est affecté
    employee_id = fields.Many2one('hr.employee', string="Employé", required=True)

    # Date d'affectation
    date_affectation = fields.Date(string="Date d'Affectation", required=True, default=fields.Date.context_today)

    # Date de retour
    date_retour = fields.Date(string="Date de Retour prévue", required=False)

    # Statut de l'affectation
    statut = fields.Selection([
        ('en_cours', 'En Cours'),
        ('terminee', 'Terminée'),
        ('perdue', 'Perdue / Non Restituée')
    ], string="Statut", default='en_cours')

    # Notes complémentaires
    note = fields.Text(string="Notes")

    @api.constrains('equipement_id')
    def _check_etat_equipement(self):
        for rec in self:
            if rec.equipement_id.etat_equipement in ['hors_service', 'vendu', 'perdu']:
                raise ValidationError(
                    "Vous ne pouvez pas affecter un équipement marqué comme hors service, vendu ou perdu."
                )

    @api.constrains('date_affectation', 'date_retour')
    def _check_dates_affectation(self):
        for rec in self:
            if rec.date_affectation and rec.date_retour and rec.date_retour < rec.date_affectation:
                raise ValidationError("La date de retour ne peut pas être antérieure à la date d'affectation.")

    @api.constrains('equipement_id')
    def _check_equipement_unique_affectation(self):
        for rec in self:
            affectations = self.env['parc.affectation'].search([
                ('equipement_id', '=', rec.equipement_id.id),
                ('id', '!=', rec.id),
                ('statut', '=', 'en_cours')
            ])
            if affectations:
                raise ValidationError("Cet équipement est déjà affecté à un autre employé.")
