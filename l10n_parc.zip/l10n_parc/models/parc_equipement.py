# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ParcEquipement(models.Model):
    _inherit = 'stock.lot'

    # Client propriétaire de l'équipement
    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_parc_client', '=', True)], required=True)

    # Employé (utilisateur final de l'équipement)
    employee_id = fields.Many2one('hr.employee', string="Employé Affecté")

    # État de l'équipement
    etat_equipement = fields.Selection([
        ('disponible', 'Disponible'),
        ('affecte', 'Affecté'),
        ('maintenance', 'En Maintenance'),
        ('perdu', 'Perdu / Volé'),
        ('vendu', 'Vendu'),
        ('hors_service', 'Hors Service')
    ], string="État", default='disponible')

    # Date de début de garantie
    garantie_debut = fields.Date(string="Début de Garantie")

    # Date de fin de garantie
    garantie_fin = fields.Date(string="Fin de Garantie")

    # Date d'affectation à l'employé
    date_affectation = fields.Date(string="Date d'Affectation")

    # Lien avec Helpdesk pour incidents
    ticket_ids = fields.One2many('helpdesk.ticket', 'equipement_id', string="Incidents liés")

    @api.constrains('employee_id', 'etat_equipement')
    def _check_modif_pendant_intervention(self):
        for rec in self:
            interventions = self.env['helpdesk.ticket'].search([
                ('equipement_id', '=', rec.id),
                ('stage_id', '=', 'en_cours')
            ])
            if interventions:
                raise ValidationError(
                    "Impossible de modifier l’équipement : une intervention est en cours."
                )

    @api.constrains('employee_id')
    def _check_affectation_garantie(self):
        for rec in self:
            if rec.garantie_fin and fields.Date.today() > rec.garantie_fin:
                raise ValidationError("Impossible d’affecter cet équipement : sa garantie est expirée.")


