# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ParcContrat(models.Model):
    _name = 'parc.contrat'
    _description = "Contrat d'Infogérance"

    name = fields.Char(string="Référence du Contrat", required=True, copy=False, default='Nouveau')

    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_parc_client', '=', True)], required=True)
    partner_id = fields.Many2one('res.partner', string='Contact Principal')

    type_contrat = fields.Selection([
        ('materiel', 'Support Matériel'),
        ('logiciel', 'Support Logiciel'),
        ('complet', 'Infogérance Complète')
    ], string="Type de Contrat", required=True)

    niveau_service = fields.Selection([
        ('standard', 'Standard (48h)'),
        ('premium', 'Premium (24h)'),
        ('critique', 'Critique (4h)')
    ], string="Niveau de Service", default='standard')

    #plan_id = fields.Many2one('sale.subscription.plan', string="Plan de Facturation")

    equipement_ids = fields.Many2many(
        'stock.lot',
        'contrat_equipement_rel',
        'contrat_id',
        'equipement_id',
        string="Équipements Couverts"
    )

    date_debut = fields.Date(string="Date de Début")
    date_fin = fields.Date(string="Date de Fin")
    statut = fields.Selection([
        ('draft', 'Brouillon'),
        ('active', 'En cours'),
        ('expired', 'Expiré'),
        ('cancelled', 'Annulé'),
    ], string="Statut", default='draft', tracking=True)

    @api.onchange('type_contrat')
    def _onchange_type_contrat(self):
        if self.type_contrat and self.name == 'Nouveau':
            prefix = {
                'materiel': 'MAT',
                'logiciel': 'LOG',
                'complet': 'INF'
            }.get(self.type_contrat, 'GEN')

            self.name = f'CONTRAT-{prefix}-XXXX'

    @api.model
    def create(self, vals):
        if vals.get('name', 'Nouveau') == 'Nouveau' and vals.get('type_contrat'):
            prefix = {
                'materiel': 'MAT',
                'logiciel': 'LOG',
                'complet': 'INF'
            }.get(vals['type_contrat'], 'GEN')

            vals['name'] = self.env['ir.sequence'].next_by_code(
                f'parc.contrat.{vals["type_contrat"]}'
            ) or f'CONTRAT-{prefix}-000'
        return super().create(vals)

    @api.constrains('date_debut', 'date_fin')
    def _check_dates_contrat(self):
        for rec in self:
            if rec.date_debut and rec.date_fin and rec.date_fin < rec.date_debut:
                raise ValidationError("La date de fin du contrat ne peut pas être antérieure à la date de début.")

    @api.constrains('statut', 'equipement_ids')
    def _check_contrat_equipements(self):
        for rec in self:
            if rec.statut == 'active' and not rec.equipement_ids:
                raise ValidationError("Un contrat actif doit couvrir au moins un équipement.")

    @api.constrains('client_id', 'equipement_ids', 'statut')
    def _check_contrat_unique_par_equipement_client(self):
        for rec in self:
            if rec.statut != 'active':
                continue
            for equip in rec.equipement_ids:
                exists = self.env['parc.contrat'].search([
                    ('id', '!=', rec.id),
                    ('statut', '=', 'active'),
                    ('client_id', '=', rec.client_id.id),
                    ('equipement_ids', 'in', equip.id)
                ])
                if exists:
                    raise ValidationError(
                        f"L’équipement {equip.name} est déjà couvert par un contrat actif avec ce client."
                    )

    @api.constrains('statut')
    def _check_contrat_cloturable(self):
        for rec in self:
            if rec.statut == 'cancelled':
                interventions = self.env['helpdesk.ticket'].search([
                    ('contrat_id', '=', rec.id),
                    ('statut', '!=', 'termine')  # ou 'cloture'
                ])
                if interventions:
                    raise ValidationError(
                        "Impossible d’annuler le contrat : certaines interventions ne sont pas clôturées.")



