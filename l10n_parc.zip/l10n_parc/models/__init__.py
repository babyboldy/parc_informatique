# -*- coding: utf-8 -*-

from . import parc_client
from . import parc_contrat
from . import parc_equipement
from . import parc_affectation
from . import parc_facturation
from . import parc_intervention
