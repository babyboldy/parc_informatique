# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ParcFacturation(models.Model):
    _inherit = 'account.move'

    # Contrat d'infogérance lié à la facture
    contrat_id = fields.Many2one('parc.contrat', string="Contrat d'Infogérance")

    # Client lié à la facture (normalement partner_id existe déjà mais on précise)
    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_parc_client', '=', True)])

    # Equipements concernés par la facture (optionnel si besoin)
    equipement_ids = fields.Many2many(
        'stock.lot',
        'facture_equipement_rel',
        'facture_id',
        'equipement_id',
        string="Équipements Facturés"
    )

    @api.constrains('contrat_id')
    def _check_facture_contrat(self):
        for rec in self:
            if not rec.contrat_id:
                raise ValidationError("Toute facture doit être liée à un contrat.")

    @api.constrains('contrat_id')
    def _check_contrat_facturable(self):
        for rec in self:
            if rec.contrat_id and rec.contrat_id.statut != 'active':
                raise ValidationError("Impossible de créer une facture pour un contrat inactif.")

