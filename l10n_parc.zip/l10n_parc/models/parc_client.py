# -*- coding: utf-8 -*-
from odoo import models, fields

class ParcClient(models.Model):
    _inherit = 'res.partner'

    # Champ spécifique pour identifier un client infogéré
    is_parc_client = fields.Boolean(string="Client Infogérance", default=False)

    # Responsable technique principal chez le client
    responsable_technique = fields.Char(string="Responsable Technique")

    # Nombre d'équipements gérés pour ce client
    nombre_equipements = fields.Integer(string="Nombre d'Équipements", compute='_compute_nombre_equipements')

    # Nombre de contrats actifs
    nombre_contrats = fields.Integer(string="Nombre de Contrats", compute='_compute_nombre_contrats')

    def _compute_nombre_equipements(self):
        for rec in self:
            rec.nombre_equipements = self.env['stock.lot'].search_count([('client_id', '=', rec.id)])

    def _compute_nombre_contrats(self):
        for rec in self:
            rec.nombre_contrats = self.env['parc.contrat'].search_count([('client_id', '=', rec.id)])
