# -*- coding: utf-8 -*-
# from odoo import http


# class L10nParc(http.Controller):
#     @http.route('/l10n_parc/l10n_parc', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/l10n_parc/l10n_parc/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('l10n_parc.listing', {
#             'root': '/l10n_parc/l10n_parc',
#             'objects': http.request.env['l10n_parc.l10n_parc'].search([]),
#         })

#     @http.route('/l10n_parc/l10n_parc/objects/<model("l10n_parc.l10n_parc"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('l10n_parc.object', {
#             'object': obj
#         })

