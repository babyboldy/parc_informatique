# -*- coding: utf-8 -*-
{
    'name': "Parc",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'contacts', 'stock', 'sale_management','sale_subscription', 'account', 'helpdesk', 'hr'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/contrat_sequence.xml',
        'views/parc_client_views.xml',
        'views/parc_contrat_views.xml',
        'views/parc_equipement_views.xml',
        'views/parc_affectation_views.xml',
        'views/parc_intervention_views.xml',
        'views/parc_facturation_views.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
    'application': True,
}

